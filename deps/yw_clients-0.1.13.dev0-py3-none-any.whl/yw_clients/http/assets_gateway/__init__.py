"""
This module gathers HTTP client & related for the :mod:`assets-gateway <youwol.backends.assets_gateway>` service.
"""

# relative
from .assets_gateway import *
