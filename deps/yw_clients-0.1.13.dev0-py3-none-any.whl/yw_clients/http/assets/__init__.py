"""
HTTP client & related for the :mod:`assets <youwol.backends.assets>` service.
"""

# relative
from .assets import *
from .models import *
